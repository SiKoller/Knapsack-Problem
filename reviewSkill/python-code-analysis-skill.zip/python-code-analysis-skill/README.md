# Python Code Analysis — Codex Skill

Repository-level Python code review skill focused on clean code, Pythonic code, SOLID, testing/refactoring, security, and design patterns.

## Install

Copy the whole `python-code-analysis-skill` directory into the skills directory used by your Codex setup, keeping `SKILL.md`, `references/`, `templates/`, and `scripts/` together.

## Example requests

- `Analyze this repository with the python-code-analysis skill and generate a report.`
- `Run a full code-quality and security analysis. Do not change code; create code-analysis-report.md.`
- `Analyze only src/ and tests/ and prioritize SOLID, testing, and security.`

The skill defaults to analysis-only and always produces a Markdown report.
