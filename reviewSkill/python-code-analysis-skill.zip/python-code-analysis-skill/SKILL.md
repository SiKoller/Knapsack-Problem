---
name: python-code-analysis
version: 1.0.0
description: Analyse Python codebases for clean code, Pythonic code, SOLID, testing/refactoring, security, and design-pattern quality, then generate an evidence-based Markdown report.
---

# Python Code Analysis Skill

Use this skill when the user asks to review, audit, analyse, assess, or improve a Python codebase. The goal is not merely to lint syntax: perform a repository-level software-engineering review and generate a report with concrete evidence and prioritized remediation.

## Core principles

Base the review on `references/review-principles.md`. In particular, assess:

- Code smells and maintainability risks.
- Pythonic idioms and resource handling.
- General code quality: cohesion, coupling, separation of concerns, DRY/KISS/YAGNI, contracts and exception handling.
- SOLID: SRP, OCP, LSP, ISP, DIP.
- Testing quality, testability, and refactoring opportunities.
- Python security, secret handling, unsafe deserialization, dependency risk, and common static-analysis findings.
- Appropriate design-pattern use; do not recommend patterns merely to increase abstraction.

## Operating mode

Default to **analysis only**. Do not modify production code unless the user explicitly asks for fixes/refactoring.

Always distinguish:

1. **Observed finding** — directly supported by code/tool output.
2. **Architectural concern** — reasoned from multiple files/components.
3. **Suggestion** — optional improvement, not a defect.

Never invent file paths, line numbers, test results, tool output, vulnerabilities, or dependency findings.

## Workflow

### 1. Establish scope

Determine the repository root and language scope. Analyse Python source, tests, configuration, dependency manifests, and relevant CI files. Typical inputs include:

- `*.py`
- `pyproject.toml`, `setup.cfg`, `setup.py`, `requirements*.txt`, lock files
- `pytest.ini`, `.coveragerc`, tox/nox configs
- CI workflows
- Docker files when relevant to Python security/runtime behavior

Exclude generated/vendor/cache paths unless the user requests otherwise, including `.git`, `.venv`, `venv`, `site-packages`, `node_modules`, `dist`, `build`, `.mypy_cache`, `.pytest_cache`, `.ruff_cache`.

### 2. Read repository context first

Before judging architecture, inspect:

- README / docs describing intended structure.
- Dependency and tooling configuration.
- Main entry points.
- Package/module boundaries.
- Tests and fixtures.

Avoid judging a deliberate framework convention as a smell without context.

### 3. Run deterministic checks when available

Run `scripts/collect_static_signals.py <repo>` first. It creates a lightweight JSON signal file using the Python AST and text heuristics. Treat these as **candidates**, not automatic defects.

Then use project-native commands when present. Prefer existing configuration. Useful tools include:

- `ruff check .` or `pylint ...` for lint/code-smell signals.
- `bandit -r <python-src>` for common Python security issues.
- `safety check` or a project-configured dependency security tool if already available.
- `pytest` for test health.
- coverage command configured by the project, if present.

Rules:

- Do not install packages or change lockfiles unless explicitly authorized.
- If a tool is unavailable, mark it `not run` rather than treating it as a pass.
- Do not fail the whole review because one optional tool fails.
- Capture commands and exit status for the report.

### 4. Perform semantic review

Inspect candidate hotspots and representative modules. For each finding, collect:

- exact file path and line/range,
- short code evidence or behavior description,
- why it matters,
- principle violated or weakened,
- severity and confidence,
- a practical remediation.

#### Code smells

Look for duplicated logic, magic numbers/constants, commented-out code, unreachable/dead code, debug `print`, unclear numeric-suffix variables, unnecessary classes, overly complex comprehensions, bare/empty exception handlers, long functions, deeply nested conditionals, shotgun changes, and mixed responsibilities.

Do **not** flag multiple early returns by default; guard clauses and early returns can improve readability.

#### Pythonic code

Check whether code uses Python idioms where they improve clarity: context managers for resource cleanup, direct iteration rather than manual indexes, useful comprehensions without excessive complexity, mappings for simple dispatch, unpacking/enumeration/zip where appropriate, and EAFP where it is clearer and safe.

Prefer readability over cleverness.

#### General design quality

Evaluate:

- Cohesion: does each unit have a focused purpose?
- Coupling: are concrete dependencies hard-coded where injection/abstraction would help?
- Separation of concerns: are persistence, domain logic, presentation, transport, etc. mixed?
- DRY: is knowledge duplicated in ways that can drift?
- KISS: is accidental complexity present?
- YAGNI: is speculative abstraction increasing maintenance cost?
- Exceptions: specific and appropriately located; no swallowed errors or user-facing tracebacks.
- Assertions: internal invariants only; not business-flow or external-input validation.

#### SOLID

Review each principle with evidence:

- **SRP** — one responsibility / one reason to change.
- **OCP** — extension should not repeatedly require editing central conditionals/components.
- **LSP** — subtypes must preserve expected behavior/contracts.
- **ISP** — clients should not depend on methods they do not need.
- **DIP** — high-level logic should depend on abstractions, not hard-coded infrastructure.

Do not force interface-heavy Java-style design into simple Python code.

#### Testing and refactoring

Assess whether unit tests are isolated, fast, repeatable, and self-validating. Also inspect integration coverage where component interactions matter. Look for brittle tests, excessive mocking, missing boundary/error tests, nondeterminism, and poor testability caused by hidden dependencies/global state.

Recommend refactoring as small behavior-preserving steps: simplify code, improve testability, and remove smells. Do not suggest broad rewrites when focused changes suffice.

#### Security

Review at minimum:

- hard-coded secrets/API keys and credential files,
- unsafe `pickle` loading of untrusted data,
- `eval`/`exec` and dynamic code execution,
- shell/subprocess construction and injection risk,
- unsafe temporary files/path handling where relevant,
- weak input validation at trust boundaries,
- dependency vulnerability signals,
- insecure exception/logging behavior,
- use of assertions for security/input checks.

Use Bandit/tool findings as evidence, but validate important findings manually and reduce obvious false positives.

#### Design patterns

Recognize existing patterns and evaluate fit. Relevant patterns from the source material include Factory, Singleton/Monostate/Borg, Builder, Adapter, Composite, Decorator, Facade, Chain of Responsibility, Template Method, Command, and State.

Recommend a pattern only when it solves a recurring design problem and improves maintainability/SOLID alignment. Explicitly warn when a Singleton introduces hidden dependencies or hurts testability.

### 5. Prioritize findings

Use these severities:

- **Critical** — credible security/data-loss/correctness issue with immediate impact.
- **High** — major security, correctness, architectural, or maintainability defect.
- **Medium** — meaningful maintainability/testability/design problem.
- **Low** — localized quality issue with limited impact.
- **Info** — suggestion, positive observation, or non-blocking opportunity.

Use confidence: `High`, `Medium`, `Low`.

A finding must include evidence. If confidence is Low, say what additional information would confirm it.

### 6. Score conservatively

Generate category scores from 0–10 for:

- Clean Code & Readability
- Pythonic Code
- Architecture & Separation of Concerns
- SOLID & Extensibility
- Testing & Testability
- Security
- Dependency / Operational Hygiene

Do not compute scores solely from issue counts. Explain each score in one sentence. The overall score is the arithmetic mean rounded to one decimal, unless the user asks for another method.

Security rule: if an unresolved Critical security issue is present, cap the overall score at 5.0 and state the cap.

### 7. Generate the report

Always create a report. Default filename:

`code-analysis-report.md`

Use `templates/report-template.md` as the structure. Fill all applicable sections. For empty sections, write `No confirmed findings` rather than deleting the section.

The report must contain:

- executive summary,
- scope and limitations,
- repository overview,
- scorecard,
- prioritized findings,
- principle-by-principle review,
- testing assessment,
- security assessment,
- design-pattern assessment,
- tool execution summary,
- prioritized action plan,
- positive observations,
- appendix with methodology.

For every confirmed issue use this structure:

```markdown
### [HIGH] PY-SRP-001 — Service mixes persistence and domain logic

**Location:** `src/service.py:42-118`  
**Confidence:** High  
**Principles:** SRP, Separation of Concerns, Testability

**Evidence:** ...

**Why it matters:** ...

**Recommendation:** ...

**Suggested change:** ...
```

Use stable finding IDs with prefixes such as:

- `PY-SMELL-*`
- `PY-PYTHONIC-*`
- `PY-SOLID-*`
- `PY-TEST-*`
- `PY-SEC-*`
- `PY-PATTERN-*`
- `PY-ARCH-*`

### 8. Final response

Tell the user:

- where the report was written,
- headline score and top 3 risks,
- which automated tools were/weren't run,
- whether code was changed.

If the user requested only a review, do not silently refactor files.
