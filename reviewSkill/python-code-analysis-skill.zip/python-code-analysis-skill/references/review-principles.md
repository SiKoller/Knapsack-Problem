# Review Principles

This reference distills the course principles used by the skill.

## 1. Code smells

Flag evidence-based occurrences of:

- Duplicated code — duplicated knowledge increases maintenance effort and drift risk.
- Magic numbers — unexplained hard-coded values should become named constants/configuration when meaningful.
- Commented-out code — remove obsolete code; version control preserves history.
- Dead/unreachable code — remove code that cannot affect behavior.
- Print debugging — use logging/structured observability for real applications.
- Numeric suffix variables — prefer collections or descriptive names when numbered variables represent a group.
- Classes that should be functions — avoid unnecessary object ceremony for stateless behavior.
- Overly complex comprehensions — concise is good only while readability remains high.
- Empty/bare exception blocks — do not silently swallow errors.

Important nuance: multiple early returns can simplify code and improve readability; do not enforce a single-return rule.

## 2. Pythonic code

Prefer Python idioms when they make intent clearer:

- `with` / context managers for resources and cleanup.
- Clear comprehensions for simple transformations/filtering.
- Dictionary dispatch for simple key-to-value/function selection instead of long repetitive branches.
- Language idioms over verbose translations from other languages.
- EAFP where directly attempting an operation and handling a specific exception is clearer than redundant pre-checks.

Do not reward cleverness over readability.

## 3. General traits of good code

### Cohesion
A component should group closely related behavior. Excessive exception types/responsibilities can signal low cohesion.

### Coupling
Hard-coded concrete dependencies create ripple effects and reduce reuse/testability. Prefer injecting collaborators or depending on stable abstractions when change pressure justifies it.

### Separation of Concerns
Distinct responsibilities should live in distinct components/layers/modules so changes remain localized.

### DRY, KISS, YAGNI

- DRY: avoid repeated knowledge/logic that can diverge.
- KISS: prefer the simplest design that clearly solves the problem.
- YAGNI: avoid speculative abstractions for requirements that do not yet exist.

### Contracts, assertions, exceptions

- Preconditions describe what a function requires.
- Postconditions describe what the function guarantees.
- Assertions are for internal invariants/correctness checks, not expected business errors or untrusted input.
- Use specific exceptions for business/runtime error handling.
- Never expose raw tracebacks to end users.
- Do not catch `AssertionError` as normal control flow.

## 4. SOLID

- **Single Responsibility Principle:** one component, one responsibility / one reason to change.
- **Open/Closed Principle:** extend behavior without repeatedly modifying stable code.
- **Liskov Substitution Principle:** subtypes must be safely substitutable for their base type/contract.
- **Interface Segregation Principle:** favor small focused interfaces; do not force clients to implement/use irrelevant operations.
- **Dependency Inversion Principle:** high-level policy should depend on abstractions rather than hard-coded low-level implementations.

Apply these idiomatically in Python; protocols, ABCs, callables, dependency injection, duck typing, and composition may all be appropriate.

## 5. Functional programming and immutability

Consider whether avoiding unnecessary mutable shared state improves predictability, thread safety, and testability. First-class/higher-order functions can simplify behavior injection where natural. Do not force functional style onto stateful domains where it reduces clarity.

## 6. Descriptors and validation

Descriptors can centralize reusable attribute validation, transformation, logging, or access rules. Recommend them only when the same cross-cutting attribute behavior occurs across multiple classes/attributes; simple properties or validation functions are often sufficient.

## 7. Testing and refactoring

Good unit tests are:

- isolated from external systems and previous state,
- fast enough to run frequently,
- repeatable/deterministic,
- self-validating.

Integration tests should validate meaningful interactions between components.

Refactoring means small, behavior-preserving changes that improve maintainability, simplify code, improve testability, and remove smells. Prefer safe sequences backed by tests.

Mutation testing can be used to assess whether tests detect behavioral changes, but it is an optional advanced signal rather than a mandatory gate.

## 8. Security

- Use static security tooling such as Bandit for common Python security issues when available.
- Check dependencies for known vulnerabilities with the project's chosen tool; the course material mentions Safety.
- Keep third-party packages updated and review vulnerability signals.
- Do not commit API keys/secrets; use environment variables or separate credential mechanisms.
- Treat Pickle as unsafe for untrusted data because unpickling can execute code; prefer safer formats (e.g. JSON; domain-specific safe model formats where applicable).
- Validate trust boundaries and avoid assertions for security checks because optimized Python may remove them.

## 9. Design patterns

Patterns are solution templates for recurring design problems, not goals by themselves.

Patterns covered by the course material include:

- Creational: Factory, Singleton/Monostate/Borg, Builder.
- Structural: Adapter, Composite, Decorator, Facade.
- Behavioral: Chain of Responsibility, Template Method, Command, State.

Use patterns to improve maintainability and SOLID alignment when there is actual recurring complexity. Avoid pattern overuse. Singleton deserves special caution because it can introduce hidden dependencies and make unit testing difficult.
