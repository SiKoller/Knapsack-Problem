#!/usr/bin/env python3
"""Collect lightweight static-analysis candidates from a Python repository.

This is intentionally conservative. Output is evidence for a Codex review, not a
standalone verdict. It uses only the Python standard library.
"""

from __future__ import annotations

import argparse
import ast
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

EXCLUDED_DIRS = {
    ".git", ".venv", "venv", "env", "site-packages", "node_modules",
    "dist", "build", "__pycache__", ".mypy_cache", ".pytest_cache", ".ruff_cache",
}

SECRET_RE = re.compile(
    r"(?i)(api[_-]?key|secret|token|password|passwd|private[_-]?key)\s*=\s*['\"][^'\"]{8,}['\"]"
)
NUMERIC_SUFFIX_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*\d+$")
COMMENTED_CODE_RE = re.compile(
    r"^\s*#\s*(def |class |if |for |while |try:|except|return |import |from |[A-Za-z_]\w*\s*=)"
)


@dataclass
class Signal:
    rule: str
    path: str
    line: int
    message: str
    confidence: str = "candidate"


def iter_python_files(root: Path) -> Iterable[Path]:
    for path in root.rglob("*.py"):
        if any(part in EXCLUDED_DIRS for part in path.parts):
            continue
        if path.is_file():
            yield path


def add(signals: list[Signal], rule: str, path: Path, line: int, message: str) -> None:
    signals.append(Signal(rule, str(path), line, message))


def analyse_ast(path: Path, tree: ast.AST, signals: list[Signal]) -> None:
    for node in ast.walk(tree):
        if isinstance(node, ast.ExceptHandler) and node.type is None:
            add(signals, "bare-except", path, node.lineno, "Bare except handler; validate whether exceptions are swallowed too broadly.")
            if len(node.body) == 1 and isinstance(node.body[0], ast.Pass):
                add(signals, "empty-except", path, node.lineno, "Bare except with pass silently discards errors.")

        if isinstance(node, ast.Call):
            name = None
            if isinstance(node.func, ast.Name):
                name = node.func.id
            elif isinstance(node.func, ast.Attribute):
                name = node.func.attr
            if name in {"eval", "exec"}:
                add(signals, "dynamic-code", path, node.lineno, f"Use of {name}(); review trust boundary and necessity.")
            if name in {"loads", "load"} and isinstance(node.func, ast.Attribute):
                owner = node.func.value
                if isinstance(owner, ast.Name) and owner.id == "pickle":
                    add(signals, "pickle-load", path, node.lineno, "pickle deserialization; unsafe for untrusted input.")
            if name == "print":
                add(signals, "print-call", path, node.lineno, "print() call; determine whether this is user output or leftover debug logging.")

        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            end = getattr(node, "end_lineno", node.lineno)
            length = max(1, end - node.lineno + 1)
            if length > 60:
                add(signals, "long-function", path, node.lineno, f"Function `{node.name}` spans ~{length} lines; inspect cohesion/responsibility.")
            if len(node.args.args) + len(node.args.kwonlyargs) > 7:
                add(signals, "many-parameters", path, node.lineno, f"Function `{node.name}` has many parameters; inspect API/cohesion.")

        if isinstance(node, ast.ClassDef):
            methods = [n for n in node.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
            if len(methods) == 1 and methods[0].name not in {"__init__", "__call__"}:
                add(signals, "class-may-be-function", path, node.lineno, f"Class `{node.name}` has a single method; check whether a function/module is clearer.")

        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store) and NUMERIC_SUFFIX_RE.match(node.id):
            add(signals, "numeric-suffix-name", path, node.lineno, f"Variable `{node.id}` ends in a number; check whether a collection/descriptive name is clearer.")

        if isinstance(node, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
            generators = node.generators
            total_ifs = sum(len(g.ifs) for g in generators)
            if len(generators) > 1 or total_ifs > 1:
                add(signals, "complex-comprehension", path, node.lineno, "Complex comprehension; verify readability versus helper function/loop.")

        if isinstance(node, ast.Assert):
            add(signals, "assert-use", path, node.lineno, "Assertion found; verify it protects an internal invariant rather than business/security validation.")

        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "open":
            # Parent links are deliberately not built. This is only a weak candidate.
            add(signals, "open-call", path, node.lineno, "open() call; confirm resource is managed with a context manager or equivalent cleanup.")


def analyse_text(path: Path, text: str, signals: list[Signal]) -> None:
    for lineno, line in enumerate(text.splitlines(), 1):
        if SECRET_RE.search(line):
            add(signals, "possible-hardcoded-secret", path, lineno, "Possible hard-coded credential/secret. Validate immediately.")
        if COMMENTED_CODE_RE.search(line):
            add(signals, "commented-out-code", path, lineno, "Line resembles commented-out executable code.")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", nargs="?", default=".")
    parser.add_argument("--output", default="code-analysis-signals.json")
    args = parser.parse_args()

    root = Path(args.repo).resolve()
    signals: list[Signal] = []
    parse_errors: list[dict[str, object]] = []
    files = list(iter_python_files(root))

    for path in files:
        rel = path.relative_to(root)
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            text = path.read_text(encoding="utf-8", errors="replace")
        analyse_text(rel, text, signals)
        try:
            tree = ast.parse(text, filename=str(rel))
        except SyntaxError as exc:
            parse_errors.append({"path": str(rel), "line": exc.lineno, "message": exc.msg})
            continue
        analyse_ast(rel, tree, signals)

    payload = {
        "repository": str(root),
        "python_files": len(files),
        "signals": [asdict(s) for s in signals],
        "parse_errors": parse_errors,
        "note": "Signals are review candidates and require semantic validation before being reported as defects.",
    }
    out = Path(args.output)
    if not out.is_absolute():
        out = root / out
    out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"Wrote {len(signals)} candidate signals to {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
