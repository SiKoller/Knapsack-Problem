# Python Code Analysis Report

**Repository:** {{repository}}  
**Analysis date:** {{date}}  
**Scope:** {{scope}}  
**Overall score:** {{overall_score}}/10

## Executive Summary

{{executive_summary}}

### Top Risks

1. {{top_risk_1}}
2. {{top_risk_2}}
3. {{top_risk_3}}

## Scope and Limitations

{{scope_and_limitations}}

## Repository Overview

{{repository_overview}}

## Scorecard

| Category | Score | Rationale |
|---|---:|---|
| Clean Code & Readability | {{clean_score}}/10 | {{clean_rationale}} |
| Pythonic Code | {{pythonic_score}}/10 | {{pythonic_rationale}} |
| Architecture & Separation of Concerns | {{architecture_score}}/10 | {{architecture_rationale}} |
| SOLID & Extensibility | {{solid_score}}/10 | {{solid_rationale}} |
| Testing & Testability | {{testing_score}}/10 | {{testing_rationale}} |
| Security | {{security_score}}/10 | {{security_rationale}} |
| Dependency / Operational Hygiene | {{dependency_score}}/10 | {{dependency_rationale}} |

## Findings Summary

| ID | Severity | Confidence | Principle | Location | Summary |
|---|---|---|---|---|---|
{{findings_table}}

## Detailed Findings

{{detailed_findings}}

## Principle-by-Principle Review

### Code Smells
{{code_smells_review}}

### Pythonic Code
{{pythonic_review}}

### General Design Quality
{{general_design_review}}

### SOLID
{{solid_review}}

## Testing & Refactoring Assessment

{{testing_assessment}}

## Security Assessment

{{security_assessment}}

## Design Pattern Assessment

{{design_pattern_assessment}}

## Tool Execution Summary

| Tool / Command | Status | Result |
|---|---|---|
{{tool_summary}}

## Prioritized Action Plan

### Immediate
{{immediate_actions}}

### Next Iteration
{{next_actions}}

### Longer Term
{{long_term_actions}}

## Positive Observations

{{positive_observations}}

## Appendix: Methodology

The review combines deterministic static signals with semantic inspection. Heuristics are treated as candidates and manually validated before becoming confirmed findings. Scores reflect impact, evidence, architecture, testability, and security rather than raw issue counts.
